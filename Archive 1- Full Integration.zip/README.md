# The Mod
This mod is designed to improve the cohesivness of different sources of biotech
## Main Sources
so, the main sources for the biotech content is:
1. Rimworld: Biotech
2. Vanilla Genetics Expanded
3. Vanilla Genetics Expanded- More Lab Stuff
4. Vanilla Factions Expanded: ancients
## Concepts
so, the plans include (but arent linited to) 
- "somehow" commecting Super Nanites and Archites
  - maybe they where a human attempt at re-creatingn Archites?
  - maybe the Ancients "transcended", and as technology improved the Super Nanites got more stable, and eventually got a new name: Archite's
- genomes for ideology stuff?
- plants?
